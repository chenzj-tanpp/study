package factory;
import car.car;
public interface factory {
	public  car proudctCar() ;
}
 