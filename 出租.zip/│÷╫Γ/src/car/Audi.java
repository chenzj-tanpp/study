package car;

public class Audi implements car{
public double fei() {
	double s=2.3;
	System.out.println(s+"  Ԫ/Сʱ");
	return s;
}
}
